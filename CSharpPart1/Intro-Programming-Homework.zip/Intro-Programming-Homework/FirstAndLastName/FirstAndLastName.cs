﻿using System;

/*
 * Problem 7 
 * Create console application that prints your first and last name, each at a separate line. 
 */


class FirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Aysun");
        Console.WriteLine("Sedatov");
    }
}

