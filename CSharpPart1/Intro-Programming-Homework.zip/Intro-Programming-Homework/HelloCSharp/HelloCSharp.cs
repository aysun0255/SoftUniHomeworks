﻿using System;

/* Problem 4 
 * Create, compile and run a “Hello C#” console application.
 * Ensure you have named the application well (e.g. “”HelloCSharp”).
 * You should submit the Visual Studio project holding the HelloCSharp class as part of your homework.
 */

class HelloCSharp
{
    static void Main()
    {
        //print "Hello C#!" to console.
        Console.WriteLine("Hello C#!");
    }
}

