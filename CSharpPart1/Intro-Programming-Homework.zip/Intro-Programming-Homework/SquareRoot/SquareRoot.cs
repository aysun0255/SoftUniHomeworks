﻿using System;

/*
 * Problem 8
 * Create a console application that calculates and prints the square root of the number 12345.
 * Find in Internet “how to calculate square root in C#”.
 */

class SquareRoot
{
    static void Main(string[] args)
    {
        //print sqrt of 12345
        Console.WriteLine(Math.Sqrt(12345));
    }
}

