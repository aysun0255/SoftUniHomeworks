﻿using System;

/*
 * Problem 14
 * Create a console application that prints the current date and time. Find in Internet how.
 */

class CurrentDateAndTime
{
    static void Main()
    {
        Console.WriteLine("Current date and time is :" + DateTime.Now);
    }
}

