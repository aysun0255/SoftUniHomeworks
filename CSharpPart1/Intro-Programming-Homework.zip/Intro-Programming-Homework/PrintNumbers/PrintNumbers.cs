﻿using System;


/* Problem 6
 * Write a program to print the numbers 1, 101 and 1001, each at a separate line.
 * Name the program correctly.
 * You should submit in your homework the Visual Studio project holding the source code of the PrintNumbers program.
 */


class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine("1");
        Console.WriteLine("101");
        Console.WriteLine("1001");
    }
}
