﻿using System;

/*
 * Problem 5
 * Modify the previous application to print your name.
 * Ensure you have named the application well (e.g. “PrintMyName”).
 * You should submit a separate project Visual Studio project holding the PrintMyName class as part of your homework. 
 */

class PrintMyName
{
    static void Main()
    {
        //write my name to console
        Console.WriteLine("My name is Aysun.");
    }
}

